﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Somativa.Models
{
    public class Compra
    {
        public Guid CompraId { get; set; }


        [DisplayName("Nota Fiscal")]
        [Required(ErrorMessage = "É necessário ter uma Nota Fiscal.")]
        [Range(0, int.MaxValue, ErrorMessage = "É necessário ter um valor positivo.")]
        public int Nota { get; set; }


        [DisplayName("Data e Hora")]
        [Required(ErrorMessage = "É necessário ter uma Data e Hora.")]
        public DateTime DataHora { get; set; }
        public IEnumerable<CompraItem>? CompraItems { get; set; }
    }
}
