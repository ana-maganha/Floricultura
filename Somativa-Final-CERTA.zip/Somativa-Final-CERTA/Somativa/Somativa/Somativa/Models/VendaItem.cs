﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Somativa.Models
{
    public class VendaItem
    {
        public Guid VendaItemId { get; set; }
        [DisplayName("Nota Fiscal")]

        public Guid VendaId { get; set; }
        public Venda? Venda { get; set; }



        [DisplayName("Produto")]
        [Required(ErrorMessage = "É necessário ter um Produto.")]
        public Guid ProdutoId { get; set; }

        public Produto? Produto { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "É necessário ter um valor positivo.")]
        [Required(ErrorMessage = "É necessário ter um Unitário.")]
        public int Quantidade { get; set; }


        [DisplayName("Unitário")]
        [Required(ErrorMessage = "É necessário ter um valor um Unitário.")]
        [Range(0, int.MaxValue, ErrorMessage = "É necessário ter um valor positivo.")]
        public decimal Unitario { get; set; }
    }
}
