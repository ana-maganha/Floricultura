﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Somativa.Models
{
    public class Cliente
    {

        public Guid ClienteId { get; set; }

        [Required(ErrorMessage = "É necessário ter um Nome.")]
        public string Nome { get; set; }


        [DisplayName("Endereço")]
        [Required(ErrorMessage = "É necessário ter um Endereço.")]
        public string Endereco { get; set; }


        [Required(ErrorMessage = "É necessário ter um Telefone.")]
        public string Telefone { get; set; }


        [DisplayName("CPF")]
        [Required(ErrorMessage = "É necessário ter um CPF.")]
        public string Cpf { get; set; }


        [DisplayName("E-mail")]
        [Required(ErrorMessage = "É necessário ter um E-mail.")]
        public string Email { get; set; }


        [Required(ErrorMessage = "É necessário ter uma Data de Nascimento.")]
        public DateTime Nascimento { get; set; }


        public IEnumerable<Venda>? Venda { get; set; }
    }
}
