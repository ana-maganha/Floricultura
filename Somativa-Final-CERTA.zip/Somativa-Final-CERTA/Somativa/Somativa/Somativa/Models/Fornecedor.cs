﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Somativa.Models
{
    public class Fornecedor
    {
        public Guid FornecedorId { get; set; }


        [Required(ErrorMessage = "É necessário ter um Nome.")]
        public string Nome { get; set; }


        [DisplayName("CNPJ")]
        [Required(ErrorMessage = "É necessário ter um CNPJ.")]
        public string Cnpj { get; set; }
        public IEnumerable<Produto>? Produtos { get; set; }
    }
}
