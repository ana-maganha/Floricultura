﻿using System.ComponentModel.DataAnnotations;

namespace Somativa.Models
{
    public class Categoria
    {
        public Guid CategoriaId { get; set; 
        }

        [Required(ErrorMessage = "É necessário ter um Nome.")]
        public string Nome { get; set; }
        public IEnumerable<Produto>? Produtos { get; set; }
    }
}
