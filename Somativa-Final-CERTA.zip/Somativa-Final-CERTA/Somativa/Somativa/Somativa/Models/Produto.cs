﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Somativa.Models
{
    public class Produto
    {
        public Guid ProdutoId { get; set; }


        [Required(ErrorMessage = "É necessário ter um Nome.")]
        public string Nome { get; set; }


        [Range(0, int.MaxValue, ErrorMessage = "É necessário ter um valor positivo.")]
        [Required(ErrorMessage = "É necessário ter um Estoque.")]
        public int Estoque { get; set; }


        [DisplayName("Preço")]
        [Range(0, int.MaxValue, ErrorMessage = "É necessário ter um valor positivo.")]
        [Required(ErrorMessage = "É necessário ter um Preço.")]
        public decimal Preco {  get; set; }


        [DisplayName("Categoria")]
        [Required(ErrorMessage = "É necessário ter uma Categoria.")]
        public Guid CategoriaId { get; set; }

        public Categoria? Categoria { get; set;}


        [DisplayName("Fornecedor")]
        [Required(ErrorMessage = "É necessário ter um Fornecedor.")]

        public Guid FornecedorId { get; set; } 

        public Fornecedor? Fornecedor { get; set; }

        public string? Foto { get; set; }    
    }
}
